public class Main {
    public static void main(String[] args) {
        double tauxCharges = 30;

        EnseignantBase[] enseignants = {
            new Permanent("Prof1", "1", "Informatique", 300),
            new Vacataire("Prof2", "2", "Electronique", 80, "Siemens"),
            new Doctorant("Prof3", "3", "Chimie", 120)
        };

        System.out.println("Coûts CPE (on ajoute " + tauxCharges + "%) \n");
        for (EnseignantBase e : enseignants) {
            System.out.println(e);
            System.out.printf("  Salaire brut : %.2f €%n", e.getSalaireBrut());
            System.out.printf("  Coût CPE     : %.2f €%n%n", e.getCoutCPE(tauxCharges));
        }

        try {
            new Permanent("", "Alice", "Info", 100);
        } catch (IllegalArgumentException ex) {
            System.out.println("Exception attendue : " + ex.getMessage());
        }
    }
}
